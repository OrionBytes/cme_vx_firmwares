﻿1.Launch Logic Program
2.Options->Preferences->Key Commands
3.Options->Import Key Commands
4.Open File"CME UF_Logic.prf"

Complete!
---------------------------
(C)Copyright 2004 Central Music Co. All rights reserved.

Central Music Co.

0711-0712 Tower D, SOHO New Town 
No. 88 Jianguo Road, Chaoyang District 100022, 
Beijing, P.R.CHINA

TEL: (86)10-8580 1115
FAX: (86)10-8580 1114
Website: www.centrmus.com  www.cme-pro.com
---------------------------