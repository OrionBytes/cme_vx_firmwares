UF Editor v1.0(beta) edition instruction:

Instruction
It advices that connect UF with MIDI port to use UF Editor v1.0(Beta).
It will be appreciate recieving the advice and suggestion from you.

Installation
Double click the file UF Editor v1.0Beta.exe to install.

-------------------------------------------------------------------------------------------------
UF Simu Drv 
Version 1.0 Beta

Description 
UF Simu Drv is a MIDI Cable driver. It is a multimedia driver can be running under Windows (versions 2000, XP).

UF Simu Drv is used to connect UF Editor outputs to any other Applications inputs. 
The MIDI data stream is passed directly from output to input -- Example:

[UF MIDI Keyboard Out]==>[UF Editor In]==>[Out UF Simu Drv In]==>[In Sequencer]            

This allows you to connect the MIDI output from one program to the MIDI input of a different program. 
This flexibility provides for almost any configuration imaginable. 

Installation 
Windows XP & Windows 2000
Under Windows XP & Windows 2000, use the Control Panel Add/Remove Hardware to install UF Simu Drv.
Click Next... Choose (*) Add/Troubleshoot.  
Click Next... Choose Add a new Device.
Click Next... Choose (*) Now, please select the Hardware from a list. 
Choose Sound, Video and Game Controllers. 
Click Next... Press [Have Disk]. Browse to the directory containing the drivers (SimuDll.dll and oemsetup.inf).
Select the UF Simu Drv driver from the list. 

Re-installation
If you want re-install UF Simu Drv, you need to first un-install and remove the existing driver via the Multimedia applet, Devices tab:  Select UF Simu Drv, and press [Remove].  
After you have removed UF Simu Drv, you need to reboot the system - if you don't the existing driver will still be in memory and won't let you increase your ports. 
After reboot, following the installation directions, and then reboot again. 

DISCLAIMER 
Provided UF Simu v1.0(Beat) drv JUNCTION DRIVER is without any warranty, expressed or implied, including but not limited to fitness for a particular purpose.

Nov.2005
CME
http://www.cme-pro.com

