﻿1.Launch Nuendo 2.0 Program
2.Devices->Device Setup->Add/Remove->Generic Remote
3.Click "Add", Select "Generic Remote", Click "Setup"
4.Click "Import", Open File "Nuendo 2.0.xml"
5.Select "UF MIDI IN" for "MIDI Input" 

Complete!
---------------------------
(C)Copyright 2004-2005 Central Music Co. All rights reserved.

Central Music Co.

0711-0712 Tower D, SOHO New Town 
No. 88 Jianguo Road, Chaoyang District 100022, 
Beijing, P.R.CHINA

TEL: (86)10-8580 1115
FAX: (86)10-8580 1114
Website: www.centrmus.com  www.cme-pro.com
---------------------------