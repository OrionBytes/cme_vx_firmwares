CME UF Series MIDI Keyboard Driver for Mac OS X 10.2, 10.3
Ver: 1.1.0
Date of Release: 2005-Jun-12

This Driver was designed for:
CME UF8/7/6/5

Follow the instructions to install:
1. Locate the driver's folder in the driver CD, launch the Setup program.
2. Follow the screen information for driver's installation.
3. Reboot the computer after installation is finished.
4. Connect the computer to UF MIDI Keyboard via USB cable, then turn on the UF MIDI Keyboard.
5. Now you can find CME UF USB MIDI in the MIDI device list of your music software.

***********************************************
Product website: www.cme-pro.com

Company information:

Central Music Co.
Beijing: 8610-8580 1115
Guangzhou: 8620-8133 8963
Hongkong: 852-2424 7368
Website: www.centrmus.com
***********************************************

All parts of the program are under protection of the Chinese and International copyright law.
