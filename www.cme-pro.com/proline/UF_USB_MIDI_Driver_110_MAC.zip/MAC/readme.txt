NOTE:

In PC Driver v1.0.5 & MAC Driver v1.1.0, 6 Remote Buttons Send MIDI Controller Message:

RTZ ->115
REW ->116
FF  ->117
REC ->114
STOP->118
PLAY->119

In PC Driver v1.0.5 & MAC Driver v1.1.0, the M.VOLUME fader sends VOLUME control message (cc#7)
to MIDI channel 1.