CME UF Series MIDI Keyboard Driver for Windows2000/XP
Ver: 1.04
Date of Release: 2005-Jun-12

This Driver was designed for:
CME UF8/7/6/5

Follow the instructions to install:
1. Connect the UF MIDI Keyboard to your computer via USB cable, then turn on the UF MIDI Keyboard.
2. Locate the driver's folder in the driver CD, launch the Setup program.
3. Follow the screen information for driver's installation.
4. Now you can find UF USB MIDI IN and UF USB MIDI OUT in the MIDI device list of your music software.

How to uninstall the driver:
1. Turn off the UF MIDI Keyboard, disconnect the USB cable.
2. Click "Start/Programs/UF MIDI USB DRIVER/UF MIDI USB DRIVER UNINSTALL����
3. Then you will see a message telling you that the driver was uninstalled.

***************************
Product website: www.cme-pro.com

Company information:

Central Music Co.
Beijing: 8610-8580 1115
Guangzhou: 8620-8133 8963
Hongkong: 852-2424 7368
Website: www.centrmus.com
***************************

All parts of the program are under protection of the Chinese and International copyright law.
